import socket
import sys

mode = sys.argv[1]
if mode in ('websocket', 'websocket-disabled'):
    with socket.create_connection(('127.0.0.1', 18080), timeout=10) as connection:
        connection.sendall(b'GET / HTTP/1.1\r\nHost: protocol.example.com\r\nUpgrade: websocket\r\n'
                           b'Connection: Upgrade\r\nSec-WebSocket-Version: 13\r\n'
                           b'Sec-WebSocket-Key: dGhlIHNhbXBsZSBub25jZQ==\r\n\r\n')
        response = b''
        expected = b'docs-pong' if mode == 'websocket' else b'docs-http-ok'
        while expected not in response:
            chunk = connection.recv(4096)
            if not chunk:
                break
            response += chunk
    print(response.decode(errors='replace'))
    if mode == 'websocket':
        assert b' 101 ' in response and b'docs-pong' in response, response
    else:
        assert b' 200 ' in response and b'docs-http-ok' in response, response
elif mode == 'tcp':
    with socket.create_connection(('127.0.0.1', 19090), timeout=10) as connection:
        connection.sendall(b'ping')
        response = connection.recv(1024)
    print(response.decode())
    assert response == b'docs-tcp:ping', response
elif mode == 'udp':
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as connection:
        connection.settimeout(10)
        connection.sendto(b'ping', ('127.0.0.1', 19091))
        response, _ = connection.recvfrom(1024)
    print(response.decode())
    assert response == b'docs-udp:ping', response
else:
    raise ValueError(mode)
