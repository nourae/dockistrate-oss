#!/usr/bin/env python3
import base64
import hashlib
import http.server
import socketserver
import threading

class HTTP(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        if self.headers.get('Upgrade', '').lower() == 'websocket':
            accept = base64.b64encode(hashlib.sha1((self.headers['Sec-WebSocket-Key'] +
                     '258EAFA5-E914-47DA-95CA-C5AB0DC85B11').encode()).digest()).decode()
            self.send_response(101)
            self.send_header('Upgrade', 'websocket')
            self.send_header('Connection', 'Upgrade')
            self.send_header('Sec-WebSocket-Accept', accept)
            self.end_headers()
            self.wfile.write(b'\x81\x09docs-pong')
            self.wfile.flush()
        else:
            self.send_response(200)
            self.end_headers()
            self.wfile.write(b'docs-http-ok\n')
class TCP(socketserver.BaseRequestHandler):
    def handle(self):
        self.request.sendall(b'docs-tcp:' + self.request.recv(1024))
class UDP(socketserver.BaseRequestHandler):
    def handle(self):
        payload, connection = self.request
        connection.sendto(b'docs-udp:' + payload, self.client_address)
for service, port, handler in [(http.server.ThreadingHTTPServer, 8080, HTTP),
                              (socketserver.ThreadingTCPServer, 9090, TCP),
                              (socketserver.ThreadingUDPServer, 9091, UDP)]:
    server = service(('0.0.0.0', port), handler)
    threading.Thread(target=server.serve_forever, daemon=True).start()
threading.Event().wait()
